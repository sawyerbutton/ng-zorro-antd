export declare class NzTabsModule {
}
