/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
export declare class NzResultTitleDirective {
}
export declare class NzResultSubtitleDirective {
}
export declare class NzResultIconDirective {
}
export declare class NzResultContentDirective {
}
export declare class NzResultExtraDirective {
}
