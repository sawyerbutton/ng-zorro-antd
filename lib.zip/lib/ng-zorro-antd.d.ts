/**
 * Generated bundle index. Do not edit.
 */
export * from './ng-zorro-antd.module';
