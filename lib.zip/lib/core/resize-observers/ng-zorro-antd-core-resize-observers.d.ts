/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { NzResizeObserverFactory as ɵa } from './resize-observers.service';
