/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
export { NzTransButtonModule } from './nz-trans-button.module';
export { NzTransButtonDirective } from './nz-trans-button.directive';
