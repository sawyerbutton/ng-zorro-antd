import { DebugElement, ModuleWithProviders, Provider, Type } from '@angular/core';
import { ComponentFixture, TestBedStatic } from '@angular/core/testing';
import { NzSafeAny } from 'ng-zorro-antd/core/types';
declare type ComponentDeps = Array<Type<NzSafeAny> | ModuleWithProviders>;
export interface ComponentBed<T> {
    bed: TestBedStatic;
    fixture: ComponentFixture<T>;
    nativeElement: HTMLElement;
    debugElement: DebugElement;
    component: T;
}
export declare function createComponentBed<T>(component: Type<T>, options?: {
    providers?: Provider[];
    declarations?: ComponentDeps;
    imports?: ComponentDeps;
}): ComponentBed<T>;
export {};
