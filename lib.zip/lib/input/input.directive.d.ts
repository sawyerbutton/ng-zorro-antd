/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ElementRef, OnChanges, Renderer2, SimpleChanges } from '@angular/core';
import { BooleanInput, NzSizeLDSType } from 'ng-zorro-antd/core/types';
import { Subject } from 'rxjs';
export declare class NzInputDirective implements OnChanges {
    static ngAcceptInputType_disabled: BooleanInput;
    nzSize: NzSizeLDSType;
    disabled: boolean;
    disabled$: Subject<boolean>;
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
}
